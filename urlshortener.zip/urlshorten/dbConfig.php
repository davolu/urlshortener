<?php
 
 $website_title="urlshorten";
 $website_name="http://localhost/urlshorten/"; //Change this to your website url. Be it offline or online.  
 
$con = mysqli_connect("localhost","root","","urlshorten");

?>