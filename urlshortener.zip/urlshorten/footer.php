    <!-- Footer -->
    <footer style="background:black;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
               
                    <p class="copyright text-muted small">Copyright &copy; <?php echo $website_title; ?>. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>